---
name: Precision Engineering
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#59413a'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#8c7168'
  outline-variant: '#e0bfb5'
  surface-tint: '#aa3600'
  primary: '#a63500'
  on-primary: '#ffffff'
  primary-container: '#c94b18'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59c'
  secondary: '#5d5e61'
  on-secondary: '#ffffff'
  secondary-container: '#e2e2e5'
  on-secondary-container: '#636467'
  tertiary: '#006389'
  on-tertiary: '#ffffff'
  tertiary-container: '#007dac'
  on-tertiary-container: '#fcfcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59c'
  on-primary-fixed: '#390c00'
  on-primary-fixed-variant: '#822800'
  secondary-fixed: '#e2e2e5'
  secondary-fixed-dim: '#c6c6c9'
  on-secondary-fixed: '#1a1c1e'
  on-secondary-fixed-variant: '#454749'
  tertiary-fixed: '#c6e7ff'
  tertiary-fixed-dim: '#81cfff'
  on-tertiary-fixed: '#001e2d'
  on-tertiary-fixed-variant: '#004c6b'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h1:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  code:
    fontFamily: monospace
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 32px
  xl: 48px
  xxl: 64px
  container-max: 1440px
  gutter: 24px
---

## Brand & Style

This design system is built on the pillars of structural integrity, precision, and clarity. It targets construction executives and project managers who require a high-reliability interface that mirrors the physical durability of their projects. 

The aesthetic leverages **Minimalism** with a **Corporate Modern** foundation. By using expansive whitespace and high-contrast typography, the system removes cognitive load, allowing users to focus on critical path items and budget data. The interface feels premium through its "digital-first" craftsmanship—every pixel is aligned to a strict grid, evoking a sense of architectural planning and professional-grade software.

## Colors

The palette is centered around a sophisticated **Terracotta Orange**, a muted and professional evolution of classic construction safety colors. This primary hue is used sparingly for calls-to-action and critical status indicators to maintain its visual impact.

The foundational colors rely on a "Deep Charcoal" for text and primary navigation elements, providing a grounded, high-contrast reading experience. Grays are neutral-cool to keep the interface feeling clean and modern. Backgrounds utilize a very subtle off-white to reduce eye strain during long periods of project auditing, while interactive surfaces remain pure white to "pop" against the canvas.

## Typography

This design system utilizes **Inter** for all applications. The typographic scale is optimized for high-density information environments where hierarchy is essential for safety and efficiency.

Headlines use tight tracking and bold weights to provide a sense of authority. Body text is set with generous line heights to ensure readability in complex technical documents. A specialized "Label-Caps" style is used for metadata, table headers, and category tags to differentiate them from actionable content.

## Layout & Spacing

The layout philosophy follows a **Fluid Grid** model based on a 12-column system. It prioritizes "spacious utility," using large margins (32px+) to frame content, preventing the UI from feeling cluttered despite high data density.

Spacing is governed by an 8px rhythm. For dashboards, a "Safe Zone" padding of 24px is standard for all container internals. Components should be grouped using proximity: 8px for related elements (e.g., label and input) and 24px+ for distinct sections or card groupings.

## Elevation & Depth

Depth in this design system is achieved through **Ambient Shadows** and **Tonal Layering**. 

1.  **Level 0 (Canvas):** The base background layer (#F9FAFB).
2.  **Level 1 (Cards/Sections):** White surfaces with a 1px border (#E2E8F0) and no shadow. Used for standard content organization.
3.  **Level 2 (Interactive/Floating):** White surfaces with a soft, diffused shadow (0px 10px 15px -3px rgba(0, 0, 0, 0.05)). Used for primary widgets and hover states.
4.  **Level 3 (Overlays):** Modals and dropdowns featuring a more pronounced shadow and a subtle backdrop blur (8px) to isolate the user's focus.

Borders are preferred over heavy shadows to maintain the "Clean & Minimal" style, using shadows only to signify temporary elevation or importance.

## Shapes

The shape language is defined by **Rounded** geometry. A base radius of 8px (0.5rem) is used for small components like buttons and inputs. For larger structural elements such as cards and containers, the radius increases to 16px (1rem). 

This softening of the UI balances the high-contrast "serious" typography, making the platform feel modern and accessible rather than purely industrial.

## Components

### Buttons
Primary buttons use a subtle vertical gradient from the Primary color to a slightly darker shade, paired with a 1px inner highlight on the top edge for a tactile, "machined" look. Secondary buttons are ghost-style with a neutral-gray border.

### Inputs
Input fields feature a 1px border and a subtle internal shadow to suggest depth. On focus, the border transitions to the Primary Orange with a soft 4px glow.

### Chips & Badges
Used for status tracking (e.g., "In Progress," "Delayed"). These use a low-saturation background tint of the status color with high-saturation text to ensure legibility without overwhelming the layout.

### Data Tables
Tables are the core of the system. They use a "no-border" horizontal style with subtle row-hover highlights. Headers are "Label-Caps" with a light gray background to anchor the data vertically.

### Progress Gauges
Custom-designed linear and circular progress bars use the accent colors (Success/Danger) with a "track" color of light gray, ensuring project health is visible at a glance.